﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CourseworkDataBase.Classes;

namespace CourseworkDataBase.Formes
{
    public partial class SubjectForms : Form
    {
        List<Subject> subjects; 

        //TODO: ctrl+r+e
        internal List<Subject> Subjects
        {
            get { return subjects; }
            set
            {
                subjects = value;

                dataGridView1.Rows.Clear();
                foreach(Subject sub in value)
                {
                    dataGridView1.Rows.Add(sub.SubjectName);
                }
            }
        }

        public SubjectForms()
        {
            InitializeComponent();
            this.RefreshSubj();
        }

        private void SubjectForms_Load(object sender, EventArgs e)
        {
            Session.timeToClose++;
        }

        private void SubjectForms_FormClosed(object sender, FormClosedEventArgs e)
        {
            Session.timeToClose--;
            if (Session.timeToClose == 0)
                Application.Exit();
        }

        private void btnAddSubj_Click(object sender, EventArgs e)
        {
            AddSubjectForm f = new AddSubjectForm();
            f.ShowDialog();
            RefreshSubj();
        }

        protected void RefreshSubj()
        {
            SubjectRepository rep = new SubjectRepository();
            this.Subjects = rep.ListOf();
            rep.Dispose();
        }

        private void btnDelSub_Click(object sender, EventArgs e)
        {
            string subname = "";
            if (dataGridView1.Rows.Count != 1) 
                subname = dataGridView1[0, dataGridView1.CurrentRow.Index].Value.ToString();

            if (subname == String.Empty)
            {
                MessageBox.Show("There is no selected subject!");
                return;
            }
            SubjectRepository rep = new SubjectRepository();
            if (!rep.CheckExist(subname))
            {
                MessageBox.Show("There is no such subject!");
                return;
            }

            if (MessageBox.Show("Are you sure? This will also delete all speciality, linked to it!", "Confirm", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.No)
                return;

            rep.Delete(new Subject() { SubjectName = subname });
            rep.Dispose();

            this.RefreshSubj();

        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            RefreshSubj();
        }
    }
}
