﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CourseworkDataBase.Classes;

namespace CourseworkDataBase.Formes
{
    public partial class UserForm : Form
    {
        List<Request> reqs;

        internal List<Request> Reqs
        {
            get { return reqs; }
            set
            {
                reqs = value;
                dataGridView1.Rows.Clear();
                foreach (Request r in value)
                {
                    dataGridView1.Rows.Add(r.UniversityName, r.SpecName, r.Accepted, r.Confirmed);
                }
            }
        }

        public UserForm()
        {
            InitializeComponent();
            RefreshRequests();
            this.Text = Session.curuser;
        }

        private void UserForm_Load(object sender, EventArgs e)
        {
            Session.timeToClose++;
        }

        private void UserForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Session.timeToClose--;
            if (Session.timeToClose == 0)
                Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            UserTestsForm f = new UserTestsForm();
            f.ShowDialog();
        }

        protected void RefreshRequests()
        {
            RequestRepository r = new RequestRepository();
            this.Reqs = r.ListOf(Session.curuser);
            r.Dispose();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            RequestForm f = new RequestForm();
            f.ShowDialog();
            RefreshRequests();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string univ = "";
            if (dataGridView1.Rows.Count != 0)
                univ = dataGridView1[0, dataGridView1.CurrentRow.Index].Value.ToString();

            string sp = "";
            if (dataGridView1.Rows.Count != 0)
                sp = dataGridView1[1, dataGridView1.CurrentRow.Index].Value.ToString();

            if(univ == String.Empty || sp == String.Empty)
            {
                MessageBox.Show("Error!");
                return;
            }

            Request req = new Request() { SpecName = sp, Login = Session.curuser, UniversityName = univ };
            RequestRepository rep = new RequestRepository();
            rep.Delete(req);
            rep.Dispose();
            RefreshRequests();
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            string univ = "";
            if (dataGridView1.Rows.Count != 0)
                univ = dataGridView1[0, dataGridView1.CurrentRow.Index].Value.ToString();

            string sp = "";
            if (dataGridView1.Rows.Count != 0)
                sp = dataGridView1[1, dataGridView1.CurrentRow.Index].Value.ToString();

            if (univ == String.Empty || sp == String.Empty)
            {
                MessageBox.Show("Error!");
                return;
            }
            Request req = new Request() { SpecName = sp, Login = Session.curuser, UniversityName = univ };
            RequestRepository rrep = new RequestRepository();
            if (!rrep.CheckExist(req))
            {
                MessageBox.Show("Doesn't exist!");
                return;
            }
            if (!rrep.IsAccepted(req))
            {
                MessageBox.Show("You aren't accepted on this spec, man!");
                return;
            }
            if(rrep.HasConfirmed(req.Login))
            {
                MessageBox.Show("You has already confirmed spec!");
                return;
            }

            req.Accepted = true;
            req.Confirmed = true;
            rrep.Update(req);
            RefreshRequests();
            rrep.Dispose();

        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
            this.Close();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            RefreshRequests();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
