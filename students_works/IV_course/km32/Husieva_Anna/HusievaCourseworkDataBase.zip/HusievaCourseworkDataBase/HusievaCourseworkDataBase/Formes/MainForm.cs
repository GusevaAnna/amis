﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using CourseworkDataBase.Classes;

namespace CourseworkDataBase.Formes
{
    public partial class MainForm : Form
    {
        List<University> unvers;
        List<Speciality> specs;

        internal List<Speciality> Specs
        {
            get { return specs; }
            set
            {
                specs = value;
                if(dataGridView1.Rows.Count!=0)
                    dataGridView1.Rows.Clear();
                if (value.Count != 0)
                    foreach (Speciality spec in value)
                    {
                        dataGridView1.Rows.Add(spec.UniversityName, spec.SpecName, spec.Quantaccept, spec.IsClosed);
                    }
            }
        }

        internal List<University> Unvers
        {
            get { return unvers; }
            set
            {
                unvers = value;
                cbUniv.Items.Clear();
                foreach (University val in value)
                {
                    cbUniv.Items.Add(val.UniversityName);
                }
                if (cbUniv.Items.Count != 0)
                    cbUniv.SelectedItem = cbUniv.Items[0];

            }
        }
        public MainForm()
        {
            InitializeComponent();
            this.RefreshUniversities();
            this.RefreshSpecialities();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            Session.timeToClose++;

        }

        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Session.timeToClose--;
            if(Session.timeToClose == 0)
            {
                Application.Exit();
            }
        }


        private void btnLogOut_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
            this.Close();
        }

        public void RefreshUniversities()
        {
            UniversityRepository rep = new UniversityRepository();
            this.Unvers = rep.ListOf();
            rep.Dispose();
        }

        private void btnDelUn_Click(object sender, EventArgs e)
        {
            if (cbUniv.Text == String.Empty)
            {
                MessageBox.Show("There is no selected university!");
                return;
            }
            UniversityRepository rep = new UniversityRepository();
            if (!rep.CheckExist(cbUniv.Text))
            {
                MessageBox.Show("There is no such university!");
                return;
            }

            if (MessageBox.Show("Are you sure? This will also delete all speciality, linked to it!", "Confirm", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.No)
                return;

            rep.Delete(new University() { UniversityName = cbUniv.Text });
            rep.Dispose();

            this.RefreshUniversities();
        }

        private void btnAddUn_Click(object sender, EventArgs e)
        {
            AddUniversityForm f = new AddUniversityForm();
            f.ShowDialog();
            this.RefreshUniversities();
        }

        private void btnAddSpec_Click(object sender, EventArgs e)
        {
            UniversityRepository rep = new UniversityRepository();

            if(!rep.CheckExist(cbUniv.Text))
            {
                MessageBox.Show("There is no such university!");
            }

            Session.univer = cbUniv.Text;
            Session.spec = speciality.Add;
            SpecialityForm f = new SpecialityForm();
            f.ShowDialog();
            RefreshSpecialities();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SubjectForms sub = new SubjectForms();
            //TODO: доеб дочернее окно
            sub.ShowDialog();
        }

        private void btnUsers_Click(object sender, EventArgs e)
        {
            UsersForm uf = new UsersForm();
            uf.ShowDialog();
        }

        protected void RefreshSpecialities()
        {
            SpecialityRepository rep = new SpecialityRepository();
            if(cbUniv.Text != "")
                this.Specs = rep.ListOf(cbUniv.Text);
            rep.Dispose();
        }

        private void btnEditSpec_Click(object sender, EventArgs e)
        {
            string univ = "";
            if (dataGridView1.Rows.Count != 0)
                univ = dataGridView1[0, dataGridView1.CurrentRow.Index].Value.ToString();

            string sp = "";
            if (dataGridView1.Rows.Count != 0)
                sp = dataGridView1[1, dataGridView1.CurrentRow.Index].Value.ToString();
            int count = 0;
            if (dataGridView1.Rows.Count != 0)
                count = Convert.ToInt32(dataGridView1[2, dataGridView1.CurrentRow.Index].Value.ToString());
            Session.count = count;

            if(univ!=String.Empty)
            {
                Session.univer = univ;
                Session.speciality = sp;
            }
            else
            {
                MessageBox.Show("There is no selected speciality");
                return;
            }

            Session.spec = speciality.Edit;
            SpecialityForm s = new SpecialityForm();
            s.ShowDialog();
            RefreshSpecialities();
        }

        private void btnDeleteSpec_Click(object sender, EventArgs e)
        {
            string univ = "";
            if (dataGridView1.Rows.Count != 0)
                univ = dataGridView1[0, dataGridView1.CurrentRow.Index].Value.ToString();

            string sp = "";
            if (dataGridView1.Rows.Count != 0)
                sp = dataGridView1[1, dataGridView1.CurrentRow.Index].Value.ToString();

            if (univ != String.Empty)
            {
                Session.univer = univ;
                Session.speciality = sp;
            }
            else
            {
                MessageBox.Show("There is no selected speciality");
                return;
            }

            if (MessageBox.Show("Are you sure? This will also delete all requests and requirements, linked to it!", "Confirm", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.No)
                return;

            Speciality s = new Speciality() { SpecName = Session.speciality, UniversityName = Session.univer };
            RequirementRepository r = new RequirementRepository();
            List<Requirement> reqs = r.ListOf(Session.univer, Session.speciality);
            foreach(Requirement item in reqs)
            {
                r.Delete(item);
            }



            SpecialityRepository rep = new SpecialityRepository();
            rep.Delete(s);
            rep.Dispose();
            RefreshSpecialities();

        }

        private void cbUniv_SelectedIndexChanged(object sender, EventArgs e)
        {
            RefreshSpecialities();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string univ = "";
            if (dataGridView1.Rows.Count != 0)
                univ = dataGridView1[0, dataGridView1.CurrentRow.Index].Value.ToString();

            string sp = "";
            if (dataGridView1.Rows.Count != 0)
                sp = dataGridView1[1, dataGridView1.CurrentRow.Index].Value.ToString();

            if (univ != String.Empty)
            {
                Session.univer = univ;
                Session.speciality = sp;
            }
            else
            {
                MessageBox.Show("There is no selected speciality");
                return;
            }
            SpecialityUserForm f = new SpecialityUserForm();
            f.ShowDialog();

        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            RefreshSpecialities();
            RefreshUniversities();
        }


    }
}
