﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CourseworkDataBase.Classes;

namespace CourseworkDataBase.Formes
{
    public partial class UsersForm : Form
    {
        List<Enrollee> users;

        internal List<Enrollee> Users
        {
            get { return users; }
            set
            {
                users = value;
                dataGridView1.Rows.Clear();
                foreach(Enrollee val in value)
                {
                    dataGridView1.Rows.Add(val.Login, val.Fio, val.Banned, val.Admin);
                }
            }
        }


        public UsersForm()
        {
            InitializeComponent();
            RefreshUsers();
        }

        private void UsersForm_Load(object sender, EventArgs e)
        {
            Session.timeToClose++;
        }

        private void UsersForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Session.timeToClose--;
            if (Session.timeToClose == 0)
                Application.Exit();
        }

        protected void RefreshUsers()
        {
            EnrolleeRepository rep = new EnrolleeRepository();
            this.Users = rep.ListOf();
            rep.Dispose();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string curuser = "";
            if (dataGridView1.Rows.Count != 0)
                curuser = dataGridView1[0, dataGridView1.CurrentRow.Index].Value.ToString();

            if (curuser == String.Empty)
            {
                MessageBox.Show("There is no selected user");
                return;
            }
            if(curuser == Session.curuser)
            {
                MessageBox.Show("You can not ban yourself");
                return;
            }
            EnrolleeRepository rep = new EnrolleeRepository();
            if (rep.IsBanned(new Enrollee() { Login = curuser}))
            {
                MessageBox.Show("This user is already banned");
                return;
            }
            if (rep.CheckExist(curuser))
            {
                rep.BanUser(curuser);
            }
            else
                MessageBox.Show("There is no such user");
            RefreshUsers();

        }

        private void btnUnban_Click(object sender, EventArgs e)
        {
            string curuser = "";
            if (dataGridView1.Rows.Count != 0)
                curuser = dataGridView1[0, dataGridView1.CurrentRow.Index].Value.ToString();

            if (curuser == String.Empty)
            {
                MessageBox.Show("There is no selected user");
                return;
            }
            if (curuser == Session.curuser)
            {
                MessageBox.Show("You can not unban yourself");
                return;
            }
            EnrolleeRepository rep = new EnrolleeRepository();
            if (!rep.IsBanned(new Enrollee() { Login = curuser }))
            {
                MessageBox.Show("This user is not banned");
                return;
            }
            if (rep.CheckExist(curuser))
            {
                rep.UnBanUser(curuser);
            }
            else
                MessageBox.Show("There is no such user");
            RefreshUsers();
        }

        private void btnMakeAd_Click(object sender, EventArgs e)
        {
            string curuser = "";
            if (dataGridView1.Rows.Count != 0)
                curuser = dataGridView1[0, dataGridView1.CurrentRow.Index].Value.ToString();

            if (curuser == String.Empty)
            {
                MessageBox.Show("There is no selected user");
                return;
            }
            if (curuser == Session.curuser)
            {
                MessageBox.Show("You can not make you more adminer");
                return;
            }
            EnrolleeRepository rep = new EnrolleeRepository();
            if (rep.IsAdmin(new Enrollee() { Login = curuser }))
            {
                MessageBox.Show("This user is already admin");
                return;
            }
            if (rep.CheckExist(curuser))
            {
                rep.MakeAdmin(curuser);
            }
            else
                MessageBox.Show("There is no such user");
            RefreshUsers();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            RefreshUsers();
        }
    }
}