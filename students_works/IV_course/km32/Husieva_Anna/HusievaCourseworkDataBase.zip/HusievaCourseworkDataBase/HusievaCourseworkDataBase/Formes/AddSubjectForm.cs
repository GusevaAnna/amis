﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CourseworkDataBase.Classes;
using System.Text.RegularExpressions;

namespace CourseworkDataBase.Formes
{
    public partial class AddSubjectForm : Form
    {


        public AddSubjectForm()
        {
            InitializeComponent();
        }

        private void AddSubjectForm_Load(object sender, EventArgs e)
        {
            Session.timeToClose++;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void AddSubjectForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Session.timeToClose--;
            if(Session.timeToClose == 0)
            {
                Application.Exit();
            }
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            if(tbName.Text == String.Empty)
            {
                MessageBox.Show("Empty field!");
                return;
            }

            //only text symbols
            Regex login = new Regex(@"^(\w+)$"); // создается шаблон, которому должен соответствовать текст
            Regex num = new Regex(@"\d");

            if (!login.IsMatch(tbName.Text) || num.IsMatch(tbName.Text)) // и если текст не соответствует, выдаем ошибку
            {
                MessageBox.Show("Not valid name!", "Error", MessageBoxButtons.OK);
                return; 
            } 



            SubjectRepository rep = new SubjectRepository();
            if(rep.CheckExist(tbName.Text))
            {
                MessageBox.Show("Such subject already exist!");
                return;
            }

            Subject sub = new Subject() { SubjectName = tbName.Text };
            rep.Insert(sub);
            rep.Dispose();
            this.Close();
        }
    }
}
