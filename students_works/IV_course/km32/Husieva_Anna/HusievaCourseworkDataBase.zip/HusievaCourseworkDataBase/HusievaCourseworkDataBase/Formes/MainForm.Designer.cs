﻿namespace CourseworkDataBase.Formes
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAddSpec = new System.Windows.Forms.Button();
            this.btnEditSpec = new System.Windows.Forms.Button();
            this.btnDeleteSpec = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.ColumnUnName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnSpecName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnQuant = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.btnUsers = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnAddUn = new System.Windows.Forms.Button();
            this.btnDelUn = new System.Windows.Forms.Button();
            this.cbUniv = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.btnLogOut = new System.Windows.Forms.Button();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnAddSpec
            // 
            this.btnAddSpec.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAddSpec.Location = new System.Drawing.Point(490, 42);
            this.btnAddSpec.Name = "btnAddSpec";
            this.btnAddSpec.Size = new System.Drawing.Size(100, 23);
            this.btnAddSpec.TabIndex = 0;
            this.btnAddSpec.Text = "Add Speciality";
            this.btnAddSpec.UseVisualStyleBackColor = true;
            this.btnAddSpec.Click += new System.EventHandler(this.btnAddSpec_Click);
            // 
            // btnEditSpec
            // 
            this.btnEditSpec.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnEditSpec.Location = new System.Drawing.Point(490, 68);
            this.btnEditSpec.Name = "btnEditSpec";
            this.btnEditSpec.Size = new System.Drawing.Size(100, 23);
            this.btnEditSpec.TabIndex = 2;
            this.btnEditSpec.Text = "Edit Speciality";
            this.btnEditSpec.UseVisualStyleBackColor = true;
            this.btnEditSpec.Click += new System.EventHandler(this.btnEditSpec_Click);
            // 
            // btnDeleteSpec
            // 
            this.btnDeleteSpec.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDeleteSpec.Location = new System.Drawing.Point(490, 97);
            this.btnDeleteSpec.Name = "btnDeleteSpec";
            this.btnDeleteSpec.Size = new System.Drawing.Size(100, 23);
            this.btnDeleteSpec.TabIndex = 3;
            this.btnDeleteSpec.Text = "Delete Speciality";
            this.btnDeleteSpec.UseVisualStyleBackColor = true;
            this.btnDeleteSpec.Click += new System.EventHandler(this.btnDeleteSpec_Click);
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Controls.Add(this.btnAddSpec);
            this.panel1.Controls.Add(this.btnDeleteSpec);
            this.panel1.Controls.Add(this.btnEditSpec);
            this.panel1.Location = new System.Drawing.Point(15, 80);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(593, 178);
            this.panel1.TabIndex = 4;
            // 
            // button3
            // 
            this.button3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button3.Location = new System.Drawing.Point(490, 126);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(100, 23);
            this.button3.TabIndex = 6;
            this.button3.Text = "View enrolliers";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnUnName,
            this.ColumnSpecName,
            this.ColumnQuant,
            this.Column1});
            this.dataGridView1.Location = new System.Drawing.Point(3, 6);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(481, 172);
            this.dataGridView1.TabIndex = 4;
            // 
            // ColumnUnName
            // 
            this.ColumnUnName.HeaderText = "UniversityName";
            this.ColumnUnName.Name = "ColumnUnName";
            // 
            // ColumnSpecName
            // 
            this.ColumnSpecName.HeaderText = "Speciality Name";
            this.ColumnSpecName.Name = "ColumnSpecName";
            // 
            // ColumnQuant
            // 
            this.ColumnQuant.HeaderText = "Quantity";
            this.ColumnQuant.Name = "ColumnQuant";
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Closed";
            this.Column1.Name = "Column1";
            // 
            // btnUsers
            // 
            this.btnUsers.Location = new System.Drawing.Point(233, 40);
            this.btnUsers.Name = "btnUsers";
            this.btnUsers.Size = new System.Drawing.Size(79, 26);
            this.btnUsers.TabIndex = 6;
            this.btnUsers.Text = "Users";
            this.btnUsers.UseVisualStyleBackColor = true;
            this.btnUsers.Click += new System.EventHandler(this.btnUsers_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.btnAddUn);
            this.panel3.Controls.Add(this.btnDelUn);
            this.panel3.Controls.Add(this.cbUniv);
            this.panel3.Location = new System.Drawing.Point(18, 8);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(209, 66);
            this.panel3.TabIndex = 6;
            // 
            // btnAddUn
            // 
            this.btnAddUn.Location = new System.Drawing.Point(3, 3);
            this.btnAddUn.Name = "btnAddUn";
            this.btnAddUn.Size = new System.Drawing.Size(98, 23);
            this.btnAddUn.TabIndex = 0;
            this.btnAddUn.Text = "Add University";
            this.btnAddUn.UseVisualStyleBackColor = true;
            this.btnAddUn.Click += new System.EventHandler(this.btnAddUn_Click);
            // 
            // btnDelUn
            // 
            this.btnDelUn.Location = new System.Drawing.Point(107, 3);
            this.btnDelUn.Name = "btnDelUn";
            this.btnDelUn.Size = new System.Drawing.Size(100, 23);
            this.btnDelUn.TabIndex = 3;
            this.btnDelUn.Text = "Delete University";
            this.btnDelUn.UseVisualStyleBackColor = true;
            this.btnDelUn.Click += new System.EventHandler(this.btnDelUn_Click);
            // 
            // cbUniv
            // 
            this.cbUniv.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbUniv.FormattingEnabled = true;
            this.cbUniv.Location = new System.Drawing.Point(3, 32);
            this.cbUniv.Name = "cbUniv";
            this.cbUniv.Size = new System.Drawing.Size(204, 21);
            this.cbUniv.TabIndex = 1;
            this.cbUniv.SelectedIndexChanged += new System.EventHandler(this.cbUniv_SelectedIndexChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(233, 8);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(79, 26);
            this.button1.TabIndex = 7;
            this.button1.Text = "Subjects";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnLogOut
            // 
            this.btnLogOut.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnLogOut.Location = new System.Drawing.Point(505, 8);
            this.btnLogOut.Name = "btnLogOut";
            this.btnLogOut.Size = new System.Drawing.Size(100, 23);
            this.btnLogOut.TabIndex = 7;
            this.btnLogOut.Text = "Log out";
            this.btnLogOut.UseVisualStyleBackColor = true;
            this.btnLogOut.Click += new System.EventHandler(this.btnLogOut_Click);
            // 
            // btnRefresh
            // 
            this.btnRefresh.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRefresh.Location = new System.Drawing.Point(505, 43);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(100, 23);
            this.btnRefresh.TabIndex = 8;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(617, 271);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.btnLogOut);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.btnUsers);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "MainForm";
            this.Text = "Admin Page";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainForm_FormClosed);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnAddSpec;
        private System.Windows.Forms.Button btnEditSpec;
        private System.Windows.Forms.Button btnDeleteSpec;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnUsers;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnAddUn;
        private System.Windows.Forms.Button btnDelUn;
        private System.Windows.Forms.ComboBox cbUniv;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnUnName;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnSpecName;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnQuant;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column1;
        private System.Windows.Forms.Button btnLogOut;
        private System.Windows.Forms.Button btnRefresh;
    }
}