﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CourseworkDataBase.Classes;

namespace CourseworkDataBase.Formes
{
    public partial class SpecialityUserForm : Form
    {
        List<Request> list;

        internal List<Request> List
        {
            get { return list; }
            set
            {
                list = value;
                if (value.Count != 0)
                {
                    dataGridView1.Rows.Clear();
                    TestRepository trep = new TestRepository();
                    RequirementRepository reqrep = new RequirementRepository();
                    List<string> sublist = reqrep.ListOfSubjects(Session.univer, Session.speciality);
                    RequestRepository rrep = new RequestRepository();
                    foreach (Request en in value)
                    {
                        dataGridView1.Rows.Add(en.Login, trep.MarkSum(en.Login, sublist), rrep.IsAccepted(new Request() {UniversityName = Session.univer, SpecName = Session.speciality, Login = en.Login }), en.Confirmed);
                    }
                    trep.Dispose();
                    rrep.Dispose();
                }
            }
        }

        public SpecialityUserForm()
        {
            InitializeComponent();
            RequestRepository rep = new RequestRepository();
            this.List = rep.ListOf(Session.univer, Session.speciality);
            rep.Dispose();

        }

        private void SpecialityUserForm_Load(object sender, EventArgs e)
        {
            Session.timeToClose++;
        }

        private void SpecialityUserForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Session.timeToClose--;
            if(Session.timeToClose == 0)
            {
                Application.Exit();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SpecialityRepository rep = new SpecialityRepository();
            if (!rep.IsClosed(Session.univer, Session.speciality))
                rep.Close(Session.univer, Session.speciality);
            else
            {
                MessageBox.Show("This speciality is already closed!");
                return;
            }
            dataGridView1.Sort(dataGridView1.Columns[1], ListSortDirection.Descending);
            
            int count = rep.Count(Session.speciality, Session.univer);
            rep.Dispose();

            RequestRepository rrep = new RequestRepository();
            for(int i=0; i<count; i++)
            {
                if (dataGridView1.Rows.Count >= i+1)
                {
                    dataGridView1.Rows[i].Cells[2].Value = true;
                    string log = dataGridView1.Rows[i].Cells[0].Value.ToString();
                    Request req = new Request() { UniversityName = Session.univer, Confirmed = false, Accepted = true, Login = log, SpecName = Session.speciality };
                    rrep.Update(req);
                }
            }
            rrep.Dispose();
        }


        public void RefreshRequirement()
        {
            RequestRepository rep = new RequestRepository();
            this.List = rep.ListOf(Session.univer, Session.speciality);
            rep.Dispose();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            RefreshRequirement();       
        }
    }
}
