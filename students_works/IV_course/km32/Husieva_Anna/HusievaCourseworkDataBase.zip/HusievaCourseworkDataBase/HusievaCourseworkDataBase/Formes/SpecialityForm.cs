﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CourseworkDataBase.Classes;
using System.Text.RegularExpressions;

namespace CourseworkDataBase.Formes
{
    public partial class SpecialityForm : Form
    {

        List<Subject> sublist;
        List<Requirement> reqs;

        internal List<Requirement> Reqs
        {
            get { return reqs; }
            set 
            { 
                reqs = value;
                comboBox1.Text = value[0].SubjectName;
                comboBox2.Text = value[1].SubjectName;
                comboBox3.Text = value[2].SubjectName;
                numericUpDown1.Value = value[0].MinQuantMark;
                numericUpDown2.Value = value[1].MinQuantMark;
                numericUpDown3.Value = value[2].MinQuantMark;
            }
        }

        internal List<Subject> Sublist
        {
            get { return sublist; }
            set
            {
                sublist = value;
                comboBox1.Items.Clear();
                comboBox2.Items.Clear();
                comboBox3.Items.Clear();
                foreach(Subject sub in value)
                {
                    comboBox1.Items.Add(sub.SubjectName);
                    comboBox2.Items.Add(sub.SubjectName);
                    comboBox3.Items.Add(sub.SubjectName);
                }

            }
        }

        public SpecialityForm()
        {
            InitializeComponent();
            if(Session.spec == speciality.Add)
            {
                Text = "Add new speciality";
                SubjectRepository rep = new SubjectRepository();
                this.Sublist = rep.ListOf();
                rep.Dispose();
            }
            if(Session.spec == speciality.Edit)
            {
                Text = "Edit speciality in "+ Session.univer;
                textBox1.Enabled = false;
                textBox1.Text = Session.speciality;
                nUDQuant.Value = Session.count;
                comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
                comboBox2.DropDownStyle = ComboBoxStyle.DropDownList;
                comboBox3.DropDownStyle = ComboBoxStyle.DropDownList;
                SubjectRepository srep = new SubjectRepository();
                this.Sublist = srep.ListOf();
                srep.Dispose();
                RequirementRepository rep = new RequirementRepository();
                this.Reqs = rep.ListOf(Session.univer, Session.speciality);
                rep.Dispose();
            }
            if(Session.spec == speciality.ReadOnly)
            {
                textBox1.Enabled = false;
                numericUpDown1.Enabled = false;
                numericUpDown2.Enabled = false;
                numericUpDown3.Enabled = false;
                nUDQuant.Enabled = false;
                comboBox1.Enabled = false;
                comboBox2.Enabled = false;
                comboBox3.Enabled = false;
                btnConfirm.Visible = false;
                SubjectRepository srep = new SubjectRepository();
                this.Sublist = srep.ListOf();
                srep.Dispose();
                RequirementRepository rep = new RequirementRepository();
                this.Reqs = rep.ListOf(Session.univer, Session.speciality);
                rep.Dispose();
            }
        }

        private void SpecialityForm_Load(object sender, EventArgs e)
        {
            Session.timeToClose++;
        }

        private void SpecialityForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Session.timeToClose--;
            if (Session.timeToClose == 0)
                Application.Exit();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            if (Session.spec == speciality.Add)
            {
                string sub1 = comboBox1.Text;
                string sub2 = comboBox2.Text;
                string sub3 = comboBox3.Text;
                if (sub1 == String.Empty || sub2 == String.Empty || sub3 == String.Empty)
                {
                    MessageBox.Show("Повинні бути вибрані усі три предмети!");
                    return;
                }
                if (sub1 == sub2 || sub1 == sub3 || sub2 == sub3)
                {
                    MessageBox.Show("Предмети повинні бути різними!");
                    return;
                }
                if (textBox1.Text == String.Empty)
                {
                    MessageBox.Show("Назва спецальності не може бути порожньою!");
                    return;
                }

                Regex login = new Regex(@"^(\w+)$"); // создается шаблон, которому должен соответствовать текст
                Regex num = new Regex(@"\d");

                if (!login.IsMatch(textBox1.Text) || num.IsMatch(textBox1.Text)) // и если текст не соответствует, выдаем ошибку
                {
                    MessageBox.Show("Not valid name!", "Error", MessageBoxButtons.OK);
                    return;
                } 
                SpecialityRepository specrep = new SpecialityRepository();
                Speciality spec = new Speciality() { UniversityName = Session.univer, SpecName = textBox1.Text, Quantaccept = (int)nUDQuant.Value };
                if (specrep.CheckExist(spec))
                {
                    MessageBox.Show("Such speciality is already exists!");
                    return;
                }
                specrep.Insert(spec);
                specrep.Dispose();

                Requirement req1 = new Requirement()
                {
                    UniversityName = Session.univer,
                    SpecName = spec.SpecName,
                    SubjectName = comboBox1.Text,
                    MinQuantMark = (int)numericUpDown1.Value
                };
                Requirement req2 = new Requirement()
                {
                    UniversityName = Session.univer,
                    SpecName = spec.SpecName,
                    SubjectName = comboBox2.Text,
                    MinQuantMark = (int)numericUpDown2.Value
                };
                Requirement req3 = new Requirement()
                {
                    UniversityName = Session.univer,
                    SpecName = spec.SpecName,
                    SubjectName = comboBox3.Text,
                    MinQuantMark = (int)numericUpDown3.Value
                };
                RequirementRepository reqrep = new RequirementRepository();
                reqrep.Insert(req1);
                reqrep.Insert(req2);
                reqrep.Insert(req3);
                reqrep.Dispose();
                this.Close();
            }

            if(Session.spec == speciality.Edit)
            {

                Speciality s = new Speciality() { SpecName = Session.speciality, UniversityName = Session.univer };
                RequirementRepository r = new RequirementRepository();
                List<Requirement> reqs = r.ListOf(Session.univer, Session.speciality);
                foreach (Requirement item in reqs)
                {
                    r.Delete(item);
                }
                SpecialityRepository specrep = new SpecialityRepository();
                specrep.Delete(s);

                string sub1 = comboBox1.Text;
                string sub2 = comboBox2.Text;
                string sub3 = comboBox3.Text;
                if (sub1 == String.Empty || sub2 == String.Empty || sub3 == String.Empty)
                {
                    MessageBox.Show("Повинні бути вибрані усі три предмети!");
                    return;
                }
                if (sub1 == sub2 || sub1 == sub3 || sub2 == sub3)
                {
                    MessageBox.Show("Предмети повинні бути різними!");
                    return;
                }

                //only text symbols
                Regex login = new Regex(@"^(\w+)$"); // создается шаблон, которому должен соответствовать текст
                Regex num = new Regex(@"\d");

                if (!login.IsMatch(textBox1.Text) || num.IsMatch(textBox1.Text)) // и если текст не соответствует, выдаем ошибку
                {
                    MessageBox.Show("Not valid name!", "Error", MessageBoxButtons.OK);
                    return;
                } 


                Speciality spec = new Speciality() { UniversityName = Session.univer, SpecName = textBox1.Text, Quantaccept = (int) nUDQuant.Value };
                specrep.Insert(spec);
                specrep.Dispose();

                Requirement req1 = new Requirement()
                {
                    UniversityName = Session.univer,
                    SpecName = spec.SpecName,
                    SubjectName = comboBox1.Text,
                    MinQuantMark = (int)numericUpDown1.Value
                };
                Requirement req2 = new Requirement()
                {
                    UniversityName = Session.univer,
                    SpecName = spec.SpecName,
                    SubjectName = comboBox2.Text,
                    MinQuantMark = (int)numericUpDown2.Value
                };
                Requirement req3 = new Requirement()
                {
                    UniversityName = Session.univer,
                    SpecName = spec.SpecName,
                    SubjectName = comboBox3.Text,
                    MinQuantMark = (int)numericUpDown3.Value
                };
                RequirementRepository reqrep = new RequirementRepository();
                reqrep.Insert(req1);
                reqrep.Insert(req2);
                reqrep.Insert(req3);
                reqrep.Dispose();
                this.Close();
            }
        }

    }
}
