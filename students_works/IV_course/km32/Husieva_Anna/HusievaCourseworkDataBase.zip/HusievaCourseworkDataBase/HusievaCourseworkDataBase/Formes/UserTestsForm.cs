﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CourseworkDataBase.Classes;

namespace CourseworkDataBase.Formes
{
    public partial class UserTestsForm : Form
    {
        List<Test> tests;

        internal List<Test> Tests
        {
            get { return tests; }
            set
            {
                tests = value;
                dataGridView1.Rows.Clear();
                foreach(Test item in value)
                {
                    dataGridView1.Rows.Add(item.SubjectName, item.Mark);
                }
            }
        }

        public UserTestsForm()
        {
            InitializeComponent();
            RefreshTests();
        }

        private void UserTestsForm_Load(object sender, EventArgs e)
        {
            Session.timeToClose++;
        }

        private void UserTestsForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Session.timeToClose--;
            if (Session.timeToClose == 0)
                Application.Exit();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            AddTestForm f = new AddTestForm();
            f.ShowDialog();
            RefreshTests();
        }

        protected void RefreshTests()
        {
            TestRepository rep = new TestRepository();
            if (rep.ListOf(Session.curuser).Count!=0)
                this.Tests = rep.ListOf(Session.curuser);
            rep.Dispose();
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            string subj = "";
            if(dataGridView1.Rows.Count!=0)
                subj = dataGridView1[0, dataGridView1.CurrentRow.Index].Value.ToString();

            if(subj == String.Empty)
            {
                MessageBox.Show("There is no selected test!");
                return;
            }

            if (MessageBox.Show("Are you sure? This will also delete all requests, linked to it!", "Confirm", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.No)
                return;

            Test t = new Test() { SubjectName = subj, Login = Session.curuser};
            TestRepository rep = new TestRepository();
            if(rep.CheckExist(t))
                rep.Delete(t);
            rep.Dispose();
            RefreshTests();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            RefreshTests();
        }
    }
}
