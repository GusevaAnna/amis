﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CourseworkDataBase.Classes;

namespace CourseworkDataBase.Formes
{
    public partial class RequestForm : Form
    {
        List<University> unvers;
        internal List<University> Unvers
        {
            get { return unvers; }
            set
            {
                unvers = value;
                comboBox1.Items.Clear();
                foreach (University val in value)
                {
                    comboBox1.Items.Add(val.UniversityName);
                }
                if (comboBox1.Items.Count != 0)
                    comboBox1.SelectedItem = comboBox1.Items[0];

            }
        }
        List<Speciality> specs;

        internal List<Speciality> Specs
        {
            get { return specs; }
            set
            {
                specs = value;
                dataGridView1.Rows.Clear();
                foreach(Speciality s in value)
                {
                    dataGridView1.Rows.Add(s.UniversityName, s.SpecName, !s.IsClosed);
                }
            }
        }

        public void RefreshUniv()
        {
            UniversityRepository rep = new UniversityRepository();
            this.Unvers = rep.ListOf();
            rep.Dispose();
        }

        public RequestForm()
        {
            InitializeComponent();
            RefreshSpec();
            RefreshUniv();
        }

        private void RequestForm_Load(object sender, EventArgs e)
        {
            Session.timeToClose++;
        }

        private void RequestForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Session.timeToClose--;
            if(Session.timeToClose == 0)
            {
                Application.Exit();
            }
        }

        private void RefreshSpec()
        {
            SpecialityRepository r = new SpecialityRepository();
            this.Specs = r.ListOf(comboBox1.Text);
            r.Dispose();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            TestRepository trep = new TestRepository();
            List<Test> ustests = trep.ListOf(Session.curuser);
            trep.Dispose();


            string univ = "";
            if (dataGridView1.Rows.Count != 0)
                univ = dataGridView1[0, dataGridView1.CurrentRow.Index].Value.ToString();

            string sp = "";
            if (dataGridView1.Rows.Count != 0)
                sp = dataGridView1[1, dataGridView1.CurrentRow.Index].Value.ToString();


            if (univ != String.Empty)
            {
                Session.univer = univ;
                Session.speciality = sp;
            }
            else
            {
                MessageBox.Show("There is no selected speciality");
                return;
            }

            SpecialityRepository sprep = new SpecialityRepository();
            if (sprep.IsClosed(Session.univer, Session.speciality))
            {
                MessageBox.Show("Прийом на дану спецальність завершений!");
                return;
            }


            RequirementRepository rrep = new RequirementRepository();            
            List<Requirement> specrecs = rrep.ListOf(univ, sp);

            int counter = 0;
            foreach(Requirement req in specrecs)
            {
                foreach (Test t in ustests)
                    if (req.IsCorrect(t))
                        counter++;
            }
            if(counter < 3)
            {
                MessageBox.Show("You can not apply for this speciality!");
                return;
            }

            Request request = new Request() { Login = Session.curuser, SpecName = Session.speciality, UniversityName = Session.univer, Accepted = false };
            RequestRepository reqrep = new RequestRepository();
            if(reqrep.CheckExist(request))
            {
                MessageBox.Show("There is such request already");
                return;
            }
            reqrep.Insert(request);
            reqrep.Dispose();
            MessageBox.Show("Success!");

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string univ = "";
            if (dataGridView1.Rows.Count != 0)
                univ = dataGridView1[0, dataGridView1.CurrentRow.Index].Value.ToString();

            string sp = "";
            if (dataGridView1.Rows.Count != 0)
                sp = dataGridView1[1, dataGridView1.CurrentRow.Index].Value.ToString();


            if (univ != String.Empty)
            {
                Session.univer = univ;
                Session.speciality = sp;
            }
            else
            {
                MessageBox.Show("There is no selected speciality");
                return;
            }
            Session.spec = speciality.ReadOnly;
            SpecialityForm f = new SpecialityForm();
            f.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            RefreshUniv();
            RefreshSpec();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SpecialityRepository r = new SpecialityRepository();
            this.Specs = r.ListOf(comboBox1.Text);
            r.Dispose();
        }

    }
}
