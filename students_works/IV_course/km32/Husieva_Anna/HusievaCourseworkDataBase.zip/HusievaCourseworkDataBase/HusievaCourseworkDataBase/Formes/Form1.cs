﻿using System;
using System.Drawing;
using System.Windows.Forms;
using CourseworkDataBase.Classes;
using CourseworkDataBase.Formes;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;

namespace CourseworkDataBase
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                DataBase db = new DataBase();
                db.Test();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
            Session.timeToClose++;

            if(Session.lr == logreg.Login)
            {
                this.Text = "Login";
                btnReg.Visible = true;
                label3.Visible = false;
                label4.Visible = false;
                tbConfPass.Visible = false;
                tbFullName.Visible = false;
                this.Size = new Size(new Point(292, 139)); 
                btnConfirm.Location = new Point(29, 64);
                btnCancel.Location = new Point(110, 64);
                btnReg.Location = new Point(191, 64);
            }
            if(Session.lr == logreg.Registration)
            {
                this.Text = "Registration";
                btnReg.Visible = false;
                label3.Visible = true;
                label4.Visible = true;
                tbConfPass.Visible = true;
                tbFullName.Visible = true;
                this.Size = new Size(new Point(292, 189));
                btnConfirm.Location = new Point(29, 116);
                btnCancel.Location = new Point(110, 116);
                btnReg.Location = new Point(191, 116);
            }
        }

         

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Session.timeToClose--;
            if(Session.timeToClose == 0)
            {
                Application.Exit();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            if(Session.lr == logreg.Login)
            {
                this.Close();
            }
            if(Session.lr == logreg.Registration)
            {
                Session.lr = logreg.Login;
                Form1 f = new Form1();
                f.Show();
                this.Close();
            }
        }

        private void btnReg_Click(object sender, EventArgs e)
        {
            Session.lr = logreg.Registration;
            Form1 f = new Form1();
            f.Show();
            this.Close();
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            if(Session.lr == logreg.Login)
            {
                if (tbLogin.Text == String.Empty || tbPass.Text == String.Empty)
                { MessageBox.Show("Fields can't be empty");
                return;
                }


                EnrolleeRepository rep = new EnrolleeRepository();
                Enrollee en = new Enrollee() { Login = tbLogin.Text, Password = DataBase.CalcMD5(tbPass.Text) };
                if (!rep.CheckExist(tbLogin.Text) || !rep.CheckUser(en))
                {
                    MessageBox.Show("Wrong user or password");
                    return;
                }
                if(rep.IsBanned(en))
                {
                    MessageBox.Show("Sorry, but you are banned");
                    return;
                }
                
                if(rep.IsAdmin(en))
                    Session.user = user.Admin;
                else
                    Session.user = user.Simple;

                if (Session.user == user.Admin)
                {
                    Session.curuser = tbLogin.Text;
                    MainForm f = new MainForm();
                    f.Show();
                    rep.Dispose();
                    this.Close();
                }
                if(Session.user == user.Simple)
                {
                    Session.curuser = tbLogin.Text;
                    UserForm f = new UserForm();
                    f.Show();
                    rep.Dispose();
                    this.Close();
                }
            }



            if(Session.lr == logreg.Registration)
            {
                if (tbLogin.Text == String.Empty || tbPass.Text == String.Empty || tbConfPass.Text == String.Empty || tbFullName.Text == String.Empty)
                {
                    MessageBox.Show("Fields can't be empty");
                    return;
                }

                if(tbConfPass.Text != tbPass.Text)
                {
                    MessageBox.Show("Passwords aren't equal");
                    return;
                }
                EnrolleeRepository rep = new EnrolleeRepository();
                if(rep.CheckExist(tbLogin.Text))
                {
                    MessageBox.Show("There is such user already");
                    return;
                }

                Enrollee en = new Enrollee() { Banned = false,
                                               Admin = false, 
                                               Login = tbLogin.Text, 
                                               Fio = tbFullName.Text, 
                                               Password = DataBase.CalcMD5(tbPass.Text) };
                rep.Insert(en);
                Session.lr = logreg.Login;
                Form1 f = new Form1();
                f.Show();
                rep.Dispose();
                this.Close();
            }
            
        }

        private void tbPass_Resize(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Normal;
        }

        private void tbPass_SizeChanged(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Normal;
        }
        

    }
}
