﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CourseworkDataBase.Classes;

namespace CourseworkDataBase.Formes
{
    public partial class AddTestForm : Form
    {
        List<Subject> subs;

        internal List<Subject> Subs
        {
            get { return subs; }
            set
            {
                subs = value;
                foreach (Subject val in value)
                {
                    comboBox1.Items.Add(val.SubjectName);
                }
                if (comboBox1.Items.Count != 0)
                    comboBox1.SelectedItem = comboBox1.Items[0];
            }
        }

        public AddTestForm()
        {
            InitializeComponent();
            SubjectRepository rep = new SubjectRepository();
            this.Subs = rep.ListOf();
            rep.Dispose();
        }

        private void AddTestForm_Load(object sender, EventArgs e)
        {
            Session.timeToClose++;
        }

        private void AddTestForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Session.timeToClose--;
            if (Session.timeToClose == 0)
                Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(comboBox1.Text == String.Empty)
            {
                MessageBox.Show("Subject should not be empty!");
                return;
            }
            if(dateTimePicker1.Value > DateTime.Now)
            {
                MessageBox.Show("You can not travel in time");
                return;
            }
            TestRepository rep = new TestRepository();
            Test t = new Test() { Login = Session.curuser, Mark = (short)numericUpDown1.Value, SubjectName = comboBox1.Text };  
            if(rep.CheckExist(t))
            {
                MessageBox.Show("Such TestFrom is already exist!");
                rep.Dispose();
                return;
            }

            
            rep.Insert(t);
            rep.Dispose();
            this.Close();
        }
    }
}
