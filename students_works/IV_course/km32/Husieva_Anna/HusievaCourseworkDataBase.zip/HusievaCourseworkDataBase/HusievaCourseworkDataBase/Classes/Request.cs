﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CourseworkDataBase.Classes
{
    class Request
    {
        string login;
        string universityName;
        string specName;
        bool accepted;
        bool confirmed;

        public bool Confirmed
        {
            get { return confirmed; }
            set { confirmed = value; }
        }

        public bool Accepted
        {
            get { return accepted; }
            set { accepted = value; }
        }

        public string SpecName
        {
            get { return specName; }
            set { specName = value; }
        }

        public string UniversityName
        {
            get { return universityName; }
            set { universityName = value; }
        }

        public string Login
        {
            get { return login; }
            set { login = value; }
        }
    }
}
