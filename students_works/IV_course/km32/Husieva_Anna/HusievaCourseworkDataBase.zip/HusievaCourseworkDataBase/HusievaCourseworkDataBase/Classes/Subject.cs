﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CourseworkDataBase.Classes
{
    class Subject
    {
        string subjectName;

        public string SubjectName
        {
            get { return subjectName; }
            set { subjectName = value; }
        }
    }
}
