﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CourseworkDataBase.Classes
{
    class Requirement
    {
        string subjectName;
        string universityName;
        string specName;
        int minQuantMark;

        
        public bool IsCorrect(Test t)
        {
            bool result = false;
            if (this.SubjectName == t.SubjectName && this.MinQuantMark <= t.Mark)
                result = true;
            return result;
        }

        public int MinQuantMark
        {
            get { return minQuantMark; }
            set { minQuantMark = value; }
        }

        public string SpecName
        {
            get { return specName; }
            set { specName = value; }
        }

        public string UniversityName
        {
            get { return universityName; }
            set { universityName = value; }
        }

        public string SubjectName
        {
            get { return subjectName; }
            set { subjectName = value; }
        }
    }
}
