﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CourseworkDataBase.Classes
{
    class Enrollee
    {
        string login;
        string password;
        string fio;
        bool admin;
        bool banned;
        //TODO: при создании переменной рефакторинг -- инкапсулировать поле (ctrl+r+e)
               

        public bool Banned
        {
            get { return banned; }
            set { banned = value; }
        }

        public bool Admin
        {
            get { return admin; }
            set { admin = value; }
        }

        public string Fio
        {
            get { return fio; }
            set { fio = value; }
        }

        public string Password
        {
            get { return password; }
            set { password = value; }
        }

        public string Login
        {
            get { return login; }
            set { login = value; }
        }
    }
}
