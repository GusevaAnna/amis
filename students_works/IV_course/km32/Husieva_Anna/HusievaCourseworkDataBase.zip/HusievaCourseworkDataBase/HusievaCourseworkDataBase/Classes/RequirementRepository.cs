﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Data;
using Oracle.ManagedDataAccess.Client;

namespace CourseworkDataBase.Classes
{
    class RequirementRepository: IRepository<Requirement>, IDisposable
    {
            OracleConnection connection;

            public RequirementRepository()
            {
                DataBase database = new DataBase();
                connection = database.Connect();
            }

            public void Insert(Requirement req)
            {
                OracleTransaction tr = connection.BeginTransaction(IsolationLevel.Serializable);

                try
                {
                    OracleCommand command = new OracleCommand() 
                    {
                        CommandText = @"Insert into Requirement
                                        (Subject_name, University_name, spec_name, min_quant_mark)
                                Values(:subname, :unname, :spname, :mqm)",
                        Connection = this.connection,
                        Transaction = tr    
                    };
                    command.Parameters.Add(new OracleParameter("subname", req.SubjectName));
                    command.Parameters.Add(new OracleParameter("unname", req.UniversityName));
                    command.Parameters.Add(new OracleParameter("spname", req.SpecName));
                    command.Parameters.Add(new OracleParameter("mqm", req.MinQuantMark));
                    command.ExecuteNonQuery();
                    tr.Commit();

                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    tr.Rollback();
                    return;
                }
            }

            public void Update(Requirement req)
            {
                OracleTransaction tr = connection.BeginTransaction(IsolationLevel.Serializable);

                try
                {
                    OracleCommand command = new OracleCommand()
                    {
                        CommandText = @"UPDATE Requirement SET
                                        Min_quant_mark = :mqm
                                        WHERE Subject_name = :subname AND University_name = :unname AND spec_name = :spname",
                        Connection = this.connection,
                        Transaction = tr
                    };
                    command.Parameters.Add(new OracleParameter("subname", req.SubjectName));
                    command.Parameters.Add(new OracleParameter("unname", req.UniversityName));
                    command.Parameters.Add(new OracleParameter("spname", req.SpecName));
                    command.Parameters.Add(new OracleParameter("mqm", req.MinQuantMark));
                    command.ExecuteNonQuery();
                    tr.Commit();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    tr.Rollback();
                    return;
                }
            }


            protected Requirement PopulateEntity(IDataReader reader)
            {
                Requirement req = new Requirement();
                req.SpecName = reader.GetString(reader.GetOrdinal("Spec_name"));
                req.SubjectName = reader.GetString(reader.GetOrdinal("Subject_name"));
                req.UniversityName = reader.GetString(reader.GetOrdinal("University_name"));
                req.MinQuantMark = reader.GetInt32(reader.GetOrdinal("Min_quant_mark"));
                return req;

            }

            public List<Requirement> ListOf(int count = 0)
            {
                OracleTransaction trans = connection.BeginTransaction(IsolationLevel.ReadCommitted);
                try
                {
                    OracleCommand command = new OracleCommand("SELECT * FROM Requirement", this.connection);
                    command.Transaction = trans;
                    if (count > 0)
                    {
                        command.CommandText += "LIMIT " + count.ToString();
                    }

                    IDataReader reader = command.ExecuteReader();

                    List<Requirement> reqs = new List<Requirement>();

                    while (reader.Read())
                    {
                        Requirement req = PopulateEntity(reader);
                        reqs.Add(req);
                    }
                    trans.Commit();
                    return reqs;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    trans.Rollback();
                    return null;
                }

            }


            public List<string> ListOfSubjects(string univ, string spname)
            {
                OracleTransaction trans = connection.BeginTransaction(IsolationLevel.ReadCommitted);
                try
                {
                    OracleCommand command = new OracleCommand("SELECT * FROM Requirement WHERE University_name = :unname AND spec_name = :spname", this.connection);
                    command.Parameters.Add(new OracleParameter("unname", univ));
                    command.Parameters.Add(new OracleParameter("spname", spname));
                    command.Transaction = trans;


                    IDataReader reader = command.ExecuteReader();
                    List<string> uns = new List<string>();

                    while (reader.Read())
                    {
                        Requirement un = PopulateEntity(reader);
                        uns.Add(un.SubjectName);
                    }
                    trans.Commit();
                    return uns;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    trans.Rollback();
                    return null;
                }
            }

            public List<Requirement> ListOf(string univ, string spec)
            {
                OracleTransaction trans = connection.BeginTransaction(IsolationLevel.ReadCommitted);
                try
                {
                    OracleCommand command = new OracleCommand("SELECT * FROM Requirement WHERE University_name = :univ AND spec_name = :spname", this.connection);
                    command.Parameters.Add(new OracleParameter("univ", univ));
                    command.Parameters.Add(new OracleParameter("spname", spec)); 
                    IDataReader reader = command.ExecuteReader();

                    List<Requirement> reqs = new List<Requirement>();

                    while (reader.Read())
                    {
                        Requirement req = PopulateEntity(reader);
                        reqs.Add(req);
                    }
                    trans.Commit();
                    return reqs;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    trans.Rollback();
                    return null;
                }

            }


            public void Delete(Requirement req)
            {
                OracleTransaction trans = connection.BeginTransaction(IsolationLevel.Serializable);
                try
                {
                    OracleCommand command = new OracleCommand
                    {
                        CommandText = @"DELETE FROM Requirement WHERE Subject_name = :subname AND University_name = :unname AND spec_name = :spname",
                        Connection = this.connection,
                        Transaction = trans
                    };
                    command.Parameters.Add(new OracleParameter("subname", req.SubjectName));
                    command.Parameters.Add(new OracleParameter("unname", req.UniversityName));
                    command.Parameters.Add(new OracleParameter("spname", req.SpecName));
                    command.ExecuteNonQuery();
                    trans.Commit();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    trans.Rollback();
                    return;
                }
            }


            public void Dispose()
            {
                connection.Close();
            }
    }
}
