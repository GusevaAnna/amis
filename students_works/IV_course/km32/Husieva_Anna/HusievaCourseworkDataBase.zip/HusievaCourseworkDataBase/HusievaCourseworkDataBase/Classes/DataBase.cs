﻿using System;
using System.Text;
using System.Data;
using Oracle.ManagedDataAccess.Client;
using System.Security.Cryptography;
using System.Configuration;

namespace CourseworkDataBase
{
    class DataBase : IDisposable
    {
        OracleConnection connection;

        //TODO: создали подключение
        public DataBase()
        {
            connection = new OracleConnection(ConfigurationManager.ConnectionStrings["Conn"].ConnectionString);
        }

        //шифрование паролей
        public static string CalcMD5(string input)
        {
            MD5 md5 = MD5.Create();
            byte[] inputBytes = Encoding.ASCII.GetBytes(input);

            byte[] hash = md5.ComputeHash(inputBytes);

            StringBuilder sb = new StringBuilder();

            for (int i = 0; i < hash.Length; i++)
            {
                sb.Append(hash[i].ToString("X2"));
            }

            return sb.ToString();
        }

        //при завершении приложения закрывает коннекшн 
        public void Dispose()
        {
            if (connection.State != ConnectionState.Closed)
            {
                connection.Close();
            }
        }

        //подключились
        public OracleConnection Connect()
        {
            connection.Open();
            return connection;
        }

        //протестили
        public void Test()
        {
            connection.Open();
            connection.Close();
        }


    }
}
