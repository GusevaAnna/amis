﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Data;
using Oracle.ManagedDataAccess.Client;

namespace CourseworkDataBase.Classes
{
    class UniversityRepository
    {
        OracleConnection connection;

        public UniversityRepository()
        {
            DataBase database = new DataBase();
            connection = database.Connect();
        }

        public void Insert(University un)
        {
            OracleTransaction tr = connection.BeginTransaction(IsolationLevel.Serializable);

            try
            {
                OracleCommand command = new OracleCommand() 
                {
                    CommandText = @"Insert into Universities
                                    (University_name)
                            Values(:name)",
                    Connection = this.connection,
                    Transaction = tr    
                };
                command.Parameters.Add(new OracleParameter("name", un.UniversityName));
                command.ExecuteNonQuery();
                tr.Commit();

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
                tr.Rollback();
                return;
            }
        }

        public void Update(University un)
        {
            OracleTransaction tr = connection.BeginTransaction(IsolationLevel.Serializable);

            try
            {
                tr.Commit();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                tr.Rollback();
                return;
            }
        }


        protected University PopulateEntity(IDataReader reader)
        {
            University un = new University();
            un.UniversityName = reader.GetString(reader.GetOrdinal("University_name"));;
            return un;
        }

        public bool CheckExist(string name)
        {
            OracleTransaction trans = connection.BeginTransaction(IsolationLevel.ReadCommitted);
            try
            {

                OracleCommand command = new OracleCommand
                {
                    CommandText = @"SELECT * FROM UNIVERSITIES WHERE UNIVERSITY_NAME = :name",
                    Connection = this.connection,
                    Transaction = trans
                };
                command.Parameters.Add(new OracleParameter("name", name));

                IDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    trans.Commit();
                    return true;
                }
                trans.Commit();
                return false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                trans.Rollback();
                return false;
            }
        }


        public List<University> ListOf(int count = 0)
        {
            OracleTransaction trans = connection.BeginTransaction(IsolationLevel.ReadCommitted);
            try
            {
                OracleCommand command = new OracleCommand("SELECT * FROM Universities", this.connection);
                command.Transaction = trans;
                if (count > 0)
                {
                    command.CommandText += "LIMIT " + count.ToString();
                }

                IDataReader reader = command.ExecuteReader();

                List<University> uns = new List<University>();

                while (reader.Read())
                {
                    University un = PopulateEntity(reader);
                    uns.Add(un);
                }
                trans.Commit();
                return uns;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                trans.Rollback();
                return null;
            }

        }

        public void Delete(University un)
        {
            OracleTransaction trans = connection.BeginTransaction(IsolationLevel.Serializable);
            try
            {
                OracleCommand command = new OracleCommand
                {
                    CommandText = @"DELETE FROM Universities WHERE UNIVERSITY_NAME = :name",
                    Connection = this.connection,
                    Transaction = trans
                };
                command.Parameters.Add(new OracleParameter("name", un.UniversityName));
                command.ExecuteNonQuery();
                trans.Commit();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                trans.Rollback();
                return;
            }
        }

        public void Dispose()
        {
            connection.Close();
        }
    }
}
