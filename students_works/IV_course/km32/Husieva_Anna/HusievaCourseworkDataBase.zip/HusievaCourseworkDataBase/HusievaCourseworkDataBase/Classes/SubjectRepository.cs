﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Data;
using Oracle.ManagedDataAccess.Client;

namespace CourseworkDataBase.Classes
{
    class SubjectRepository : IRepository<Subject>, IDisposable
    {
        OracleConnection connection;

        public SubjectRepository()
        {
            DataBase database = new DataBase();
            connection = database.Connect();
        }

        public void Insert(Subject sub)
        {
            OracleTransaction tr = connection.BeginTransaction(IsolationLevel.Serializable);

            try
            {
                OracleCommand command = new OracleCommand() 
                {
                    CommandText = @"Insert into Subject
                                    (Subject_name)
                            Values(:subname)",
                    Connection = this.connection,
                    Transaction = tr    
                };
                command.Parameters.Add(new OracleParameter("subname", sub.SubjectName));
                command.ExecuteNonQuery();
                tr.Commit();

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
                tr.Rollback();
                return;
            }
        }

        public void Update(Subject sub)
        {
            OracleTransaction tr = connection.BeginTransaction(IsolationLevel.Serializable);

            try
            {
                tr.Commit();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                tr.Rollback();
                return;
            }
        }


        protected Subject PopulateEntity(IDataReader reader)
        {
            Subject sub = new Subject();
            sub.SubjectName = reader.GetString(reader.GetOrdinal("Subject_name"));;
            return sub;
        }

        public bool CheckExist(string name)
        {
            OracleTransaction trans = connection.BeginTransaction(IsolationLevel.ReadCommitted);
            try
            {

                OracleCommand command = new OracleCommand
                {
                    CommandText = @"SELECT * FROM SUBJECT WHERE SUBJECT_NAME = :name",
                    Connection = this.connection,
                    Transaction = trans
                };
                command.Parameters.Add(new OracleParameter("name", name));

                IDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    trans.Commit();
                    return true;
                }
                trans.Commit();
                return false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                trans.Rollback();
                return false;
            }
        }


        public List<Subject> ListOf(int count = 0)
        {
            OracleTransaction trans = connection.BeginTransaction(IsolationLevel.ReadCommitted);
            try
            {
                OracleCommand command = new OracleCommand("SELECT * FROM Subject", this.connection);
                command.Transaction = trans;
                if (count > 0)
                {
                    command.CommandText += "LIMIT " + count.ToString();
                }

                IDataReader reader = command.ExecuteReader();

                List<Subject> subs = new List<Subject>();

                while (reader.Read())
                {
                    Subject sub = PopulateEntity(reader);
                    subs.Add(sub);
                }
                trans.Commit();
                return subs;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                trans.Rollback();
                return null;
            }

        }

        public void Delete(Subject sub)
        {
            OracleTransaction trans = connection.BeginTransaction(IsolationLevel.Serializable);
            try
            {
                OracleCommand command = new OracleCommand
                {
                    CommandText = @"DELETE FROM Subject WHERE Subject_name = :subname",
                    Connection = this.connection,
                    Transaction = trans
                };
                command.Parameters.Add(new OracleParameter("subname", sub.SubjectName));
                command.ExecuteNonQuery();
                trans.Commit();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                trans.Rollback();
                return;
            }
        }

        public void Dispose()
        {
            connection.Close();
        }


    }
}
