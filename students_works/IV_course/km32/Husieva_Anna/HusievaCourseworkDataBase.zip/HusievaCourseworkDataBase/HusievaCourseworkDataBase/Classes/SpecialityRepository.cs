﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Data;
using Oracle.ManagedDataAccess.Client;

namespace CourseworkDataBase.Classes
{
    class SpecialityRepository : IRepository<Speciality>, IDisposable
    {
        OracleConnection connection;

        public SpecialityRepository()
        {
            DataBase database = new DataBase();
            connection = database.Connect();
        }

        public void Insert(Speciality un)
        {
            OracleTransaction tr = connection.BeginTransaction(IsolationLevel.Serializable);

            try
            {
                OracleCommand command = new OracleCommand()
                {
                    CommandText = @"Insert into University
                                        (University_name, quant_accept, spec_name, closed)
                                Values(:unname, :qaccept, :spname, :close)",
                    Connection = this.connection,
                    Transaction = tr
                };
                command.Parameters.Add(new OracleParameter("unname", un.UniversityName));
                command.Parameters.Add(new OracleParameter("qaccept", (int)un.Quantaccept));
                command.Parameters.Add(new OracleParameter("spname", un.SpecName));
                command.Parameters.Add(new OracleParameter("spname", un.IsClosed ? 1 : 0));
                command.ExecuteNonQuery();
                tr.Commit();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                tr.Rollback();
                return;
            }
        }

        public void Update(Speciality un)
        {
            OracleTransaction tr = connection.BeginTransaction(IsolationLevel.Serializable);

            try
            {
                OracleCommand command = new OracleCommand()
                {
                    CommandText = @"UPDATE University SET
                                        quant_accept = :qa, Closed = :close
                                        WHERE UNIVERSITY_NAME = :unname AND SPEC_NAME = :spname",
                    Connection = this.connection,
                    Transaction = tr
                };
                command.Parameters.Add("qa", un.Quantaccept);
                command.Parameters.Add("close", un.IsClosed ? 1 : 0);
                command.Parameters.Add("unname", un.UniversityName);
                command.Parameters.Add("spname", un.SpecName);
                command.ExecuteNonQuery();
                tr.Commit();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                tr.Rollback();
                return;
            }
        }

        public bool CheckExist(Speciality spec)
        {
            OracleTransaction trans = connection.BeginTransaction(IsolationLevel.ReadCommitted);
            try
            {

                OracleCommand command = new OracleCommand
                {
                    CommandText = @"SELECT * FROM University WHERE University_name = :unname AND spec_name = :spname",
                    Connection = this.connection,
                    Transaction = trans
                };
                command.Parameters.Add(new OracleParameter("unname", spec.UniversityName));
                command.Parameters.Add(new OracleParameter("spname", spec.SpecName));

                IDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    trans.Commit();
                    return true;
                }
                trans.Commit();
                return false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                trans.Rollback();
                return false;
            }
        }



        protected Speciality PopulateEntity(IDataReader reader)
        {
            Speciality un = new Speciality();
            un.SpecName = reader.GetString(reader.GetOrdinal("spec_name"));
            un.UniversityName = reader.GetString(reader.GetOrdinal("University_name"));
            un.Quantaccept = reader.GetInt32(reader.GetOrdinal("quant_accept"));
            un.IsClosed = reader.GetInt32(reader.GetOrdinal("closed")) == 1;
            return un;

        }

        public List<Speciality> ListOf(int count = 0)
        {
            OracleTransaction trans = connection.BeginTransaction(IsolationLevel.ReadCommitted);
            try
            {
                OracleCommand command = new OracleCommand("SELECT * FROM University", this.connection);
                command.Transaction = trans;
                if (count > 0)
                {
                    command.CommandText += "LIMIT " + count.ToString();
                }

                IDataReader reader = command.ExecuteReader();

                List<Speciality> uns = new List<Speciality>();

                while (reader.Read())
                {
                    Speciality un = PopulateEntity(reader);
                    uns.Add(un);
                }
                trans.Commit();
                return uns;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                trans.Rollback();
                return null;
            }

        }

        public List<Speciality> ListOf(string univ)
        {
            OracleTransaction trans = connection.BeginTransaction(IsolationLevel.ReadCommitted);
            try
            {
                OracleCommand command = new OracleCommand("SELECT * FROM University WHERE University_name = :unname", this.connection);
                command.Parameters.Add(new OracleParameter("unname", univ));
                command.Transaction = trans;


                IDataReader reader = command.ExecuteReader();
                List<Speciality> uns = new List<Speciality>();

                while (reader.Read())
                {
                    Speciality un = PopulateEntity(reader);
                    uns.Add(un);
                }
                trans.Commit();
                return uns;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                trans.Rollback();
                return null;
            }

        }

        public bool IsClosed(string univ, string spec)
        {

            OracleTransaction trans = connection.BeginTransaction(IsolationLevel.ReadCommitted);

            try
            {

                OracleCommand command = new OracleCommand("SELECT * FROM University WHERE University_name = :unname AND spec_name = :sp", this.connection);
                command.Parameters.Add(new OracleParameter("unname", univ));
                command.Parameters.Add(new OracleParameter("sp", spec));
                command.Transaction = trans;


                IDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    Speciality un = PopulateEntity(reader);
                    trans.Commit();
                    return un.IsClosed;
                }
                trans.Commit();
                return false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                trans.Rollback();
                return false;
            }

        }

        public void Close(string univ, string spec)
        {
            OracleTransaction trans = connection.BeginTransaction(IsolationLevel.ReadCommitted);
            try
            {
                OracleCommand command = new OracleCommand("UPDATE University SET Closed = 1 WHERE University_name = :unname AND spec_name = :sp", this.connection);
                command.Parameters.Add(new OracleParameter("unname", univ));
                command.Parameters.Add(new OracleParameter("sp", spec));
                command.Transaction = trans;


                command.ExecuteNonQuery();
                trans.Commit();
                return ;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                trans.Rollback();
                return ;
            }

        }


        public int Count(string spname, string univ)
        {
            OracleTransaction trans = connection.BeginTransaction(IsolationLevel.ReadCommitted);
            try
            {
                OracleCommand command = new OracleCommand("SELECT * FROM University WHERE University_name = :unname AND spec_name = :sp", this.connection);
                command.Parameters.Add(new OracleParameter("unname", univ));
                command.Parameters.Add(new OracleParameter("sp", spname));
                command.Transaction = trans;


                IDataReader reader = command.ExecuteReader();

                List<Speciality> uns = new List<Speciality>();

                if (reader.Read())
                {
                    Speciality un = PopulateEntity(reader);
                    trans.Commit();
                    return un.Quantaccept;
                }
                trans.Commit();
                return 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                trans.Rollback();
                return 0;
            }
        }

        public void Delete(Speciality un)
        {
            OracleTransaction trans = connection.BeginTransaction(IsolationLevel.Serializable);
            try
            {
                OracleCommand command = new OracleCommand
                {
                    CommandText = @"DELETE FROM University WHERE University_name = :unname AND spec_name = :spname",
                    Connection = this.connection,
                    Transaction = trans
                };
                command.Parameters.Add(new OracleParameter("unname", un.UniversityName));
                command.Parameters.Add(new OracleParameter("spname", un.SpecName));
                command.ExecuteNonQuery();
                trans.Commit();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                trans.Rollback();
                return;
            }
        }

        public void Dispose()
        {
            connection.Close();
        }
    }
}
