﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Data;
using Oracle.ManagedDataAccess.Client;

namespace CourseworkDataBase.Classes
{
    class TestRepository : IRepository<Test>, IDisposable
    {
        OracleConnection connection;

        public TestRepository()
        {
            DataBase database = new DataBase();
            connection = database.Connect();
        }

        public void Insert(Test t)
        {
            OracleTransaction tr = connection.BeginTransaction(IsolationLevel.Serializable);

            try
            {
                OracleCommand command = new OracleCommand()
                {
                    CommandText = @"Insert into Test
                                        (Login, Subject_name, mark)
                                Values(:login, :subname, :mark)",
                    Connection = this.connection,
                    Transaction = tr
                };
                command.Parameters.Add(new OracleParameter("login", t.Login));
                command.Parameters.Add(new OracleParameter("subname", t.SubjectName));
                command.Parameters.Add(new OracleParameter("mark", t.Mark));
                command.ExecuteNonQuery();
                tr.Commit();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                tr.Rollback();
                return;
            }
        }

        public void Update(Test t)
        {
            OracleTransaction tr = connection.BeginTransaction(IsolationLevel.Serializable);

            try
            {
                OracleCommand command = new OracleCommand()
                {
                    CommandText = @"UPDATE Test SET
                                        Mark = :mark
                                        WHERE Subject_name = :subname AND Login = :login",
                    Connection = this.connection,
                    Transaction = tr
                };
                command.Parameters.Add(new OracleParameter("login", t.Login));
                command.Parameters.Add(new OracleParameter("subname", t.SubjectName));
                command.Parameters.Add(new OracleParameter("mark", t.Mark));
                command.ExecuteNonQuery();
                tr.Commit();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                tr.Rollback();
                return;
            }
        }

        public bool CheckExist(Test t)
        {
            OracleTransaction trans = connection.BeginTransaction(IsolationLevel.ReadCommitted);
            try
            {

                OracleCommand command = new OracleCommand
                {
                    CommandText = @"SELECT * FROM Test WHERE Subject_name = :s AND login = :l",
                    Connection = this.connection,
                    Transaction = trans
                };
                command.Parameters.Add(new OracleParameter("s", t.SubjectName));
                command.Parameters.Add(new OracleParameter("l", t.Login));

                IDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    trans.Commit();
                    return true;
                }
                trans.Commit();
                return false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                trans.Rollback();
                return false;
            }
        }

        public void Delete(Test t)
        {
            OracleTransaction trans = connection.BeginTransaction(IsolationLevel.Serializable);
            try
            {
                OracleCommand command = new OracleCommand
                {
                    CommandText = @"DELETE FROM Test WHERE Subject_name = :s AND login = :l",
                    Connection = this.connection,
                    Transaction = trans
                };
                command.Parameters.Add(new OracleParameter("s", t.SubjectName));
                command.Parameters.Add(new OracleParameter("l", t.Login));
                command.ExecuteNonQuery();
                trans.Commit();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                trans.Rollback();
                return;
            }
        }

        protected Test PopulateEntity(IDataReader reader)
        {
            Test t = new Test();
            t.Login = reader.GetString(reader.GetOrdinal("Login"));
            t.SubjectName = reader.GetString(reader.GetOrdinal("Subject_name"));
            t.Mark = (short)reader.GetInt32(reader.GetOrdinal("Mark"));
            return t;

        }

        public List<Test> ListOf(int count = 0)
        {
            OracleTransaction trans = connection.BeginTransaction(IsolationLevel.ReadCommitted);
            try
            {
                OracleCommand command = new OracleCommand("SELECT * FROM Test", this.connection);
                command.Transaction = trans;
                if (count > 0)
                {
                    command.CommandText += "LIMIT " + count.ToString();
                }

                IDataReader reader = command.ExecuteReader();

                List<Test> tests = new List<Test>();

                while (reader.Read())
                {
                    Test t = PopulateEntity(reader);
                    tests.Add(t);
                }
                trans.Commit();
                return tests;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                trans.Rollback();
                return null;
            }

        }

        public List<Test> ListOf(string login)
        {
            OracleTransaction trans = connection.BeginTransaction(IsolationLevel.ReadCommitted);
            try
            {
                OracleCommand command = new OracleCommand("SELECT * FROM Test WHERE Login = :log", this.connection);
                command.Parameters.Add(new OracleParameter("log", login));
                command.Transaction = trans;


                IDataReader reader = command.ExecuteReader();

                List<Test> tests = new List<Test>();

                while (reader.Read())
                {
                    Test t = PopulateEntity(reader);
                    tests.Add(t);
                }
                trans.Commit();
                return tests;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                trans.Rollback();
                return null;
            }

        }

        public int MarkSum(string login, List<string> list)
        {
            OracleTransaction trans = connection.BeginTransaction(IsolationLevel.ReadCommitted);
            try
            {
                OracleCommand command = new OracleCommand("SELECT * FROM Test WHERE Login = :log", this.connection);
                command.Parameters.Add(new OracleParameter("log", login));
                command.Transaction = trans;


                IDataReader reader = command.ExecuteReader();

                List<Test> tests = new List<Test>();

                while (reader.Read())
                {
                    Test t = PopulateEntity(reader);
                    if(list.Contains(t.SubjectName))
                        tests.Add(t);
                }
                trans.Commit();
                int result = 0;
                foreach (Test item in tests)
                {
                    result += item.Mark;
                }
                return result;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                trans.Rollback();
                return 0;
            }
        }


        public void Dispose()
        {
            connection.Close();
        }

    }
}
