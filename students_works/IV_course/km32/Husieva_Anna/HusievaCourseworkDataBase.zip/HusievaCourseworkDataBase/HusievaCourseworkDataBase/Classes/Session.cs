﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CourseworkDataBase.Classes
{
    public static class Session
    {
        public static logreg lr;
        public static speciality spec;
        public static user user;
        public static int timeToClose = 0;
        //TODO: для передачи данных между формами
        public static string univer;
        public static string curuser;
        public static string speciality;
        public static int count;

    }

    public enum logreg { Login, Registration};
    public enum user { Simple, Admin};
    public enum speciality { Add, Edit, ReadOnly};
}
