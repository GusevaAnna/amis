﻿using System;
using System.Collections.Generic;
using Oracle.ManagedDataAccess.Client;
using System.Data;
using System.Windows.Forms;

namespace CourseworkDataBase.Classes
{
    class RequestRepository : IRepository<Request>, IDisposable
    {
        OracleConnection connection;

        public RequestRepository()
        {
            DataBase database = new DataBase();
            connection = database.Connect();
        }

        public void Insert(Request req)
        {
            OracleTransaction tr = connection.BeginTransaction(IsolationLevel.Serializable);

            try
            {
                OracleCommand command = new OracleCommand()
                {
                    CommandText = @"Insert into Request
                                        (University_name, accepted, spec_name, login, confirmed)
                                Values(:unname, :accept, :spname, :login, :conf)",
                    Connection = this.connection,
                    Transaction = tr
                };
                command.Parameters.Add(new OracleParameter("unname", req.UniversityName));
                command.Parameters.Add(new OracleParameter("accept", req.Accepted ? 1 : 0));
                command.Parameters.Add(new OracleParameter("spname", req.SpecName));
                command.Parameters.Add(new OracleParameter("login", req.Login));
                command.Parameters.Add(new OracleParameter("conf", req.Accepted ? 1 : 0));
                command.ExecuteNonQuery();
                tr.Commit();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                tr.Rollback();
                return;
            }
        }

        public bool CheckExist(Request r)
        {
            OracleTransaction trans = connection.BeginTransaction(IsolationLevel.ReadCommitted);
            try
            {

                OracleCommand command = new OracleCommand
                {
                    CommandText = @"SELECT * FROM Request WHERE Login = :log AND university_name = :unname AND spec_name = :spname",
                    Connection = this.connection,
                    Transaction = trans
                };
                command.Parameters.Add(new OracleParameter("log", r.Login));
                command.Parameters.Add(new OracleParameter("unname", r.UniversityName));
                command.Parameters.Add(new OracleParameter("spname", r.SpecName));

                IDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    trans.Commit();
                    return true;
                }
                trans.Commit();
                return false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                trans.Rollback();
                return false;
            }
        }

        public bool IsAccepted(Request req)
        {
            OracleTransaction trans = connection.BeginTransaction(IsolationLevel.ReadCommitted);
            try
            {

                OracleCommand command = new OracleCommand
                {
                    CommandText = @"SELECT * FROM Request WHERE Login = :log AND Spec_name = :sp AND University_name = :un",
                    Connection = this.connection,
                    Transaction = trans
                };
                command.Parameters.Add(new OracleParameter("log", req.Login));
                command.Parameters.Add(new OracleParameter("sp", req.SpecName));
                command.Parameters.Add(new OracleParameter("un", req.UniversityName));

                IDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    Request r = PopulateEntity(reader);
                    trans.Commit();
                    return r.Accepted;
                }
                trans.Commit();
                return false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                trans.Rollback();
                return false;
            }
        }

        public bool HasConfirmed(string login)
        {
            OracleTransaction trans = connection.BeginTransaction(IsolationLevel.ReadCommitted);
            try
            {

                OracleCommand command = new OracleCommand
                {
                    CommandText = @"SELECT * FROM Request WHERE Login = :log",
                    Connection = this.connection,
                    Transaction = trans
                };
                command.Parameters.Add(new OracleParameter("log", login));

                bool result = false;
                IDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    Request req = PopulateEntity(reader);
                    if (req.Confirmed)
                        result = true;
                }
                trans.Commit();
                return result;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                trans.Rollback();
                return false;
            }
        }


        public void Update(Request req)
        {
            OracleTransaction tr = connection.BeginTransaction(IsolationLevel.Serializable);

            try
            {
                OracleCommand command = new OracleCommand()
                {
                    CommandText = @"UPDATE Request SET
                                        accepted = :acc, confirmed = :conf
                                        WHERE University_name = :unname AND login = :log AND spec_name = :spname",
                    Connection = this.connection,
                    Transaction = tr
                };
                command.Parameters.Add(new OracleParameter("acc", req.Accepted ? 1 : 0));
                command.Parameters.Add(new OracleParameter("conf", req.Confirmed ? 1 : 0));
                command.Parameters.Add(new OracleParameter("unname", req.UniversityName));
                command.Parameters.Add(new OracleParameter("log", req.Login));
                command.Parameters.Add(new OracleParameter("spname", req.SpecName));
                command.ExecuteNonQuery();
                tr.Commit();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                tr.Rollback();
                return;
            }
        }


        protected Request PopulateEntity(IDataReader reader)
        {
            Request un = new Request();
            un.SpecName = reader.GetString(reader.GetOrdinal("spec_name"));
            un.UniversityName = reader.GetString(reader.GetOrdinal("University_name"));
            un.Accepted = reader.GetInt32(reader.GetOrdinal("accepted")) == 1;
            un.Confirmed = reader.GetInt32(reader.GetOrdinal("confirmed")) == 1;
            un.Login = reader.GetString(reader.GetOrdinal("Login"));
            return un;

        }

        public List<Request> ListOf(int count = 0)
        {
            OracleTransaction trans = connection.BeginTransaction(IsolationLevel.ReadCommitted);
            try
            {
                OracleCommand command = new OracleCommand("SELECT * FROM Request", this.connection);
                command.Transaction = trans;
                if (count > 0)
                {
                    command.CommandText += "LIMIT " + count.ToString();
                }

                IDataReader reader = command.ExecuteReader();

                List<Request> uns = new List<Request>();

                while (reader.Read())
                {
                    Request un = PopulateEntity(reader);
                    uns.Add(un);
                }
                trans.Commit();
                return uns;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                trans.Rollback();
                return null;
            }

        }

        public List<Request> ListOf(string login)
        {
            OracleTransaction trans = connection.BeginTransaction(IsolationLevel.ReadCommitted);
            try
            {
                OracleCommand command = new OracleCommand("SELECT * FROM Request WHERE Login = :log", this.connection);
                command.Parameters.Add("log", login);
                command.Transaction = trans;

                IDataReader reader = command.ExecuteReader();

                List<Request> uns = new List<Request>();

                while (reader.Read())
                {
                    Request un = PopulateEntity(reader);
                    uns.Add(un);
                }
                trans.Commit();
                return uns;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                trans.Rollback();
                return null;
            }

        }

        public List<Request> ListOf(string univ, string spec)
        {
            OracleTransaction trans = connection.BeginTransaction(IsolationLevel.ReadCommitted);
            try
            {
                OracleCommand command = new OracleCommand("SELECT * FROM Request WHERE University_name = :uname AND Spec_name = :spname", this.connection);
                command.Parameters.Add("uname", univ);
                command.Parameters.Add("spname", spec);
                command.Transaction = trans;

                IDataReader reader = command.ExecuteReader();

                List<Request> uns = new List<Request>();

                while (reader.Read())
                {
                    Request un = PopulateEntity(reader);
                    uns.Add(un);
                }
                trans.Commit();
                return uns;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                trans.Rollback();
                return null;
            }

        }

        public void Delete(Request un)
        {
            OracleTransaction trans = connection.BeginTransaction(IsolationLevel.Serializable);
            try
            {
                OracleCommand command = new OracleCommand
                {
                    CommandText = @"DELETE FROM Request WHERE University_name = :unname AND Login = :log AND spec_name = :spname",
                    Connection = this.connection,
                    Transaction = trans
                };
                command.Parameters.Add(new OracleParameter("unname", un.UniversityName));
                command.Parameters.Add(new OracleParameter("log", un.Login));
                command.Parameters.Add(new OracleParameter("spname", un.SpecName));
                command.ExecuteNonQuery();
                trans.Commit();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                trans.Rollback();
                return;
            }
        }

        public void Dispose()
        {
            connection.Close();
        }

    }
}
