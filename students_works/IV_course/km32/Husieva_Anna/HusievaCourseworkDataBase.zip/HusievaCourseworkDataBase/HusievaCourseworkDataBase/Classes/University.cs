﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CourseworkDataBase.Classes
{
    class University
    {
        string universityName;

        public string UniversityName
        {
            get { return universityName; }
            set { universityName = value; }
        }
    }
}
