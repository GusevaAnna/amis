﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CourseworkDataBase.Classes
{
    class Test
    {
        string login;
        string subjectName;
        short mark;

        public short Mark
        {
            get { return mark; }
            set { mark = value; }
        }

        public string SubjectName
        {
            get { return subjectName; }
            set { subjectName = value; }
        }

        public string Login
        {
            get { return login; }
            set { login = value; }
        }

    }
}
