﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CourseworkDataBase.Classes
{
    class Speciality
    {
        string universityName;
        int quantaccept;
        string specName;
        bool isClosed;

        public bool IsClosed
        {
            get { return isClosed; }
            set { isClosed = value; }
        }

        public string SpecName
        {
            get { return specName; }
            set { specName = value; }
        }

        public int Quantaccept
        {
            get { return quantaccept; }
            set { quantaccept = value; }
        }

        public string UniversityName
        {
            get { return universityName; }
            set { universityName = value; }
        }
    }
}
