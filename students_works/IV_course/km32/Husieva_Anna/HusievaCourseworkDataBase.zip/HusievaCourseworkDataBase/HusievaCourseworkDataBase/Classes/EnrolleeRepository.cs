﻿using System;
using System.Collections.Generic;
using Oracle.ManagedDataAccess.Client;
using System.Data;
using System.Windows.Forms;

namespace CourseworkDataBase.Classes
{

    class EnrolleeRepository : IRepository<Enrollee>, IDisposable
    {
        OracleConnection connection;

        public EnrolleeRepository()
        {
            //TODO: создали новый экземпляр класса ДАТАБАЗЕ, для создания отдельного открытого соединения, для невозникновения щекотливых ситуаций между разными соединениями
            DataBase database = new DataBase();
            connection = database.Connect();
        }

        public void Insert(Enrollee en)
        {
            OracleTransaction tr = connection.BeginTransaction(IsolationLevel.Serializable);

            try
            {
                OracleCommand command = new OracleCommand() 
                {
                    CommandText = @"Insert into Enrollee
                                    (Login, Password, FIO, Admin, Banned)
                            Values(:log, :pass, :fio, :ad, :ban)",
                                                                 //TODO: this - в данном экземпляре класса
                    Connection = this.connection,
                    Transaction = tr     
                };
                //делаем хуевую конструкцию, т.к., если бы передавали просто переменную, она бы стрингом передавалась (имя)
                command.Parameters.Add(new OracleParameter("log", en.Login));
                command.Parameters.Add(new OracleParameter("pass", en.Password));
                command.Parameters.Add(new OracleParameter("fio", en.Fio));
                command.Parameters.Add(new OracleParameter("ad", en.Admin ? 1 : 0));
                command.Parameters.Add(new OracleParameter("ban", en.Banned ? 1 : 0));
                //не ждем ответа, вольные хлеьа
                command.ExecuteNonQuery();
                tr.Commit();

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
                tr.Rollback();
                return;
            }
        }

        public void Update(Enrollee en)
        {
            OracleTransaction tr = connection.BeginTransaction(IsolationLevel.Serializable);

            try
            {
                OracleCommand command = new OracleCommand()
                {
                    CommandText = @"UPDATE Enrollee SET
                                    Password = :pass,
                                    FIO = :fio,
                                    Admin = :ad,
                                    Banned = :ban
                                    WHERE login = :log",
                    Connection = this.connection,
                    Transaction = tr
                };
                command.Parameters.Add(new OracleParameter("log", en.Login));
                command.Parameters.Add(new OracleParameter("pass", en.Password));
                command.Parameters.Add(new OracleParameter("fio", en.Fio));
                command.Parameters.Add(new OracleParameter("ad", en.Admin ? 1 : 0));
                command.Parameters.Add(new OracleParameter("ban", en.Banned ? 1 : 0));
                command.ExecuteNonQuery();
                tr.Commit();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                tr.Rollback();
                return;
            }
        }

        //TODO: почитать ф12
        protected Enrollee PopulateEntity(IDataReader reader)
        {
            Enrollee en = new Enrollee();
            en.Login = reader.GetString(reader.GetOrdinal("Login"));
            en.Password = reader.GetString(reader.GetOrdinal("Password"));
            en.Fio = reader.GetString(reader.GetOrdinal("FIO"));
            en.Admin = reader.GetInt32(reader.GetOrdinal("Admin")) == 1;
            en.Banned = reader.GetInt32(reader.GetOrdinal("Banned")) == 1;
            return en;

        }

        public bool CheckExist(string login)
        {
            OracleTransaction trans = connection.BeginTransaction(IsolationLevel.ReadCommitted);
            try
            {

                OracleCommand command = new OracleCommand
                {
                    CommandText = @"SELECT * FROM view1 WHERE Login = :log",
                    Connection = this.connection,
                    Transaction = trans
                };
                command.Parameters.Add(new OracleParameter("log", login));

                IDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    trans.Commit();
                    return true;
                }
                trans.Commit();
                return false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                trans.Rollback();
                return false;
            }
        }


        public bool CheckUser(Enrollee en)
        {
            OracleTransaction trans = connection.BeginTransaction(IsolationLevel.ReadCommitted);
            try
            {

                OracleCommand command = new OracleCommand
                {
                    CommandText = @"SELECT * FROM view1 WHERE Login = :log AND Password = :pas",
                    Connection = this.connection,
                    Transaction = trans
                };
                command.Parameters.Add(new OracleParameter("log", en.Login));
                command.Parameters.Add(new OracleParameter("pas", en.Password));
                IDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    trans.Commit();
                    return true;
                }
                trans.Commit();
                return false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                trans.Rollback();
                return false;
            }
        }

        public bool IsAdmin(Enrollee en)
        {
            OracleTransaction trans = connection.BeginTransaction(IsolationLevel.ReadCommitted);
            try
            {

                OracleCommand command = new OracleCommand
                {
                    CommandText = @"SELECT * FROM Enrollee WHERE Login = :log",
                    Connection = this.connection,
                    Transaction = trans
                };
                command.Parameters.Add(new OracleParameter("log", en.Login));
                IDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    Enrollee enrol = PopulateEntity(reader);
                    if (enrol.Admin)
                    {
                        trans.Commit();
                        return true;
                    }
                }
                trans.Commit();
                return false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                trans.Rollback();
                return false;
            }
        }

        public bool IsBanned(Enrollee en)
        {
            OracleTransaction trans = connection.BeginTransaction(IsolationLevel.ReadCommitted);
            try
            {

                OracleCommand command = new OracleCommand
                {
                    CommandText = @"SELECT * FROM Enrollee WHERE Login = :log",
                    Connection = this.connection,
                    Transaction = trans
                };
                command.Parameters.Add(new OracleParameter("log", en.Login));
                IDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    Enrollee enrol = PopulateEntity(reader);
                    if (enrol.Banned)
                    {
                        trans.Commit();
                        return true;
                    }
                }
                trans.Commit();
                return false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                trans.Rollback();
                return false;
            }

        }

        public void BanUser(string login)
        {
            OracleTransaction tr = connection.BeginTransaction(IsolationLevel.Serializable);

            try
            {
                OracleCommand command = new OracleCommand()
                {
                    CommandText = @"UPDATE Enrollee SET
                                    Banned = 1
                                    WHERE login = :log",
                    Connection = this.connection,
                    Transaction = tr
                };
                command.Parameters.Add(new OracleParameter("log", login));
                command.ExecuteNonQuery();
                tr.Commit();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                tr.Rollback();
                return;
            }

        }

        public void MakeAdmin(string login)
        {
            OracleTransaction tr = connection.BeginTransaction(IsolationLevel.Serializable);

            try
            {
                OracleCommand command = new OracleCommand()
                {
                    CommandText = @"UPDATE Enrollee SET
                                    Admin = 1
                                    WHERE login = :log",
                    Connection = this.connection,
                    Transaction = tr
                };
                command.Parameters.Add(new OracleParameter("log", login));
                command.ExecuteNonQuery();
                tr.Commit();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                tr.Rollback();
                return;
            }

        }
        public void UnBanUser(string login)
        {
            OracleTransaction tr = connection.BeginTransaction(IsolationLevel.Serializable);

            try
            {
                OracleCommand command = new OracleCommand()
                {
                    CommandText = @"UPDATE Enrollee SET
                                    Banned = 0
                                    WHERE login = :log",
                    Connection = this.connection,
                    Transaction = tr
                };
                command.Parameters.Add(new OracleParameter("log", login));
                command.ExecuteNonQuery();
                tr.Commit();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                tr.Rollback();
                return;
            }

        }

        public List<Enrollee> ListOf(int count = 0)
        {
            OracleTransaction trans = connection.BeginTransaction(IsolationLevel.ReadCommitted);
            try
            {
                //TODO: чтобы лишний раз базу не мучать
                OracleCommand command = new OracleCommand("SELECT * FROM Enrollee", this.connection);
                command.Transaction = trans;
                if (count > 0)
                {
                    command.CommandText += "LIMIT " + count.ToString();
                }

                IDataReader reader = command.ExecuteReader();

                List<Enrollee> ens = new List<Enrollee>();

                while (reader.Read())
                {
                    Enrollee en = PopulateEntity(reader);
                    ens.Add(en);
                }
                trans.Commit();
                return ens;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                trans.Rollback();
                return null;
            }

        }

        public void Delete(Enrollee en)
        {
            OracleTransaction trans = connection.BeginTransaction(IsolationLevel.Serializable);
            try
            {
                OracleCommand command = new OracleCommand
                {
                    CommandText = @"DELETE FROM ENROLLEE WHERE Login = :log",
                    Connection = this.connection,
                    Transaction = trans
                };

                command.Parameters.Add(new OracleParameter("log", en.Login));
                command.ExecuteNonQuery();
                trans.Commit();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                trans.Rollback();
                return;
            }
        }

        public void Dispose()
        {
            connection.Close();
        }
    }
}
